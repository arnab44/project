package com.jpa.learning.myjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

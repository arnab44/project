package com.jpa.learning.myjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyJpaApplication.class, args);
	}

}
